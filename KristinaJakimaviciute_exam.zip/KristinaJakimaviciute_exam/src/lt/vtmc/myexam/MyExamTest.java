package lt.vtmc.myexam;

import lt.vtmc.exam.TransportManager;
import lt.vtmc.exam.test.BaseTest;

public class MyExamTest extends BaseTest {

	@Override
	protected TransportManager createTransportManager() {
		return new TransportManagerImpl();
	}

}
