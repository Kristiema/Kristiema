package lt.vtmc.myexam;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import lt.vtmc.exam.Bus;
import lt.vtmc.exam.Passenger;
import lt.vtmc.exam.PassengerPredicate;
import lt.vtmc.exam.SeatIsOccupiedException;
import lt.vtmc.exam.TransportManager;

public class TransportManagerImpl implements TransportManager {
	
	private List<Passenger> passengers= new ArrayList<>();
	private List<Bus> buss = new ArrayList<>();

	@Override
	public Bus createBus(String id, int seats) {
		Bus newBus = new Bus (id, seats);
		buss.add(newBus);
		return newBus;
	}

	@Override
	public Passenger createPassenger(String name, String surname, int age) {
		Passenger newPassenger = new Passenger (name, surname, age);
		passengers.add(newPassenger);
		return newPassenger;
	}

	@Override
	public List<Passenger> findPassengersBy(String busId, PassengerPredicate predicate) {
		return buss.stream().filter(b -> b.getId() == busId).findAny().get().getPassengers().stream()
				.filter(p -> predicate.test(p)).collect(Collectors.toList());
	}
	

	@Override
	public double getAveragePassengerAge(String busId) {
		return buss.stream().filter(b -> b.getId() == busId).findAny().get().getPassengers().stream()
				.mapToInt(p -> p.getAge()).average().getAsDouble();
	}

	@Override
	public Bus getBusById(String busId) {
		for (Bus bus :buss) {
			if (bus.getId() == busId) {
				return bus;
			}
		}
		return null;
	}
	
	@Override
	public List<Bus> getCreatedBuses() {
		// TODO Auto-generated method stub
		return buss;
	}

	@Override
	public Passenger getOldestPassenger(String busId) {
		return buss.stream().filter(b -> b.getId() == busId).findAny().get().getPassengers().stream().max(Comparator.comparing(Passenger::getAge)).get();
	}

	@Override
	public Collection<Passenger> getOrderedPassengers(String busId) {
		return buss.stream().filter(b -> b.getId() == busId).findAny().get().getPassengers().stream()
				.sorted(Comparator.comparing(Passenger::getSurname).thenComparing(Passenger::getName))
				.collect(Collectors.toList());
	}

	@Override
	public List<Passenger> getPassengers(String busId) {
		return buss.stream().filter(b -> b.getId() == busId).findAny().get().getPassengers();
		
	}

	@Override
	public void registerPassenger(Bus bus, int seatNo, Passenger passenger) throws SeatIsOccupiedException {
		if (bus.isSeatOccupied(seatNo)) {
			throw new SeatIsOccupiedException();
		}
		bus.registerPassenger(seatNo, passenger);
	}

}
